# Keyboard Layout

## Hindi
![Hindi Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/hindi.png)

## Gujarati
![Gujarati Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/gujarati.png)

## Marathi
![Marathi Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/marathi.png)

## Kannada
![Kannada Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/kannada.png)

## Tamil
![Tamil Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/tamil.png)

## Punjabi
![Punjabi Layout](https://github.com/Firozmemon/Android-Custom-Keyboard/blob/master/img/punjabi.png)
